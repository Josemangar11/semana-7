﻿using System;

namespace L1_JMGM_1141521
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese su nombre: ");
            string nombre = Console.ReadLine();

            Console.WriteLine("Hola mundo");
            Console.WriteLine("soy" + nombre);

            Console.Write("Hola mundo");
            Console.Write("soy" + nombre);

            Console.ReadKey();
        }
    }
}
