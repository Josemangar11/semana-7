﻿using System;

namespace Tarea_Semana_8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("segundo programa");
            Console.Write("Nombre:");
            string Nombre = Console.ReadLine();
            Console.Write("Edad: ");
            string Edad = Console.ReadLine();
            Console.Write("Carrera: ");
            string Carrera = Console.ReadLine();
            Console.Write("Carnet: ");
            string Carnet = Console.ReadLine();

            Console.Write("Soy " + Nombre);
            Console.Write(" tengo " + Edad);
            Console.Write(" años y estudio la carrera de " + Carrera);
            Console.Write(" Mi numero de carnet es " + Carnet);
            Console.ReadKey();
        }
    }
}





